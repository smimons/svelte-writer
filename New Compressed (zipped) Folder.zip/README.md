# Svelte Writer
## A Simple Text Editor written in Svelte

