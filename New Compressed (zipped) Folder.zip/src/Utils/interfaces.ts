export interface Page {
    timestamp: string;
    title: string;
    body: string;

}