import App from './Components/App.svelte';

const app = new App({
	target: document.body,
});

export default app;